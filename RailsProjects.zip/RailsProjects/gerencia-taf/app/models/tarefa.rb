class Tarefa < ActiveRecord::Base
	validates_presence_of :nome, message:'Campo obrigatório'
	validates_length_of :nome, maximum:100, menssage:'limite de 100 caracteres'
	validates_presence_of :descricao, message:'Campo obrigatório'
	validates_length_of :descricao, maximum:300, message:'limite de 300 caracteres'
	validates_presence_of :status, message:'Campo obrigatorio'
end
