require 'test_helper'

class TarefaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
