class CreateTarefas < ActiveRecord::Migration[5.2]
  def change
    create_table :tarefas do |t|
      t.string :nome
      t.string :descricao
      t.date :inicio
      t.date :previsao
      t.string :status

      t.timestamps null: false #cria 2 colunas uma para uma para data de criação e outra para data de alteração
    end
  end
end
